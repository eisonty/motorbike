SET NAMES UTF8;
DROP DATABASE IF EXISTS motorbike;
CREATE DATABASE motorbike CHARSET=UTF8;
USE motorbike;
-- url资源表
create table url
(
    carimage char(255),
    video char(50),
    slideshow char(255)
);
INSERT INTO url
VALUES("[4630_w2000.jpg,4629_w2000.jpg,4964_w2000.jpg,3917_j85qtd92_2600146.png,4965_w2000.jpg,3917_j85qrn8f_4473502.png,3086_w2000.jpg]", "halei(3038826).mp4", "[3917_j5nn1kw5.jpg,3917_j5nn4iw0.jpg,2722_w2000.jpg]");

-- 新闻表
create table news(
    nid INT PRIMARY KEY auto_increment,
    title char
(50) NOT NULL,
    content char
(255) NOT NULL
);
INSERT INTO news
VALUES(null, "融入更多新元素，哈雷STREET ROD", "在三月份，哈雷全新推出了STREET ROD，这辆新车不仅让人想到了此前的STREET 750，而且从前些天哈雷公布的官方售价看，98888元的STREET ROD要比STREET 750在国内高出1万块，有人不禁要问了，这俩车发动机如此相似到底是不是STREET 750换了个壳？");
INSERT INTO news
VALUES(null, "清凉薄荷味的戴维森 Street Road 750 ROD", "这辆改装车是由HD Street 750 改装而来，奥地利车行NCT Motorcycles 在从哈雷经销商那里接到这辆新车时，对方告知他们预算和时间都非常有限，因为改装成品将会在今年九月初的European Bike Week聚会上当作抽奖奖品，这个活动今年在奥地利举行，是欧洲地区哈雷车主的年度例行盛事，今年刚好满20周年。");

-- 公司表
create table company
(
    cname char(50) NOT NULL,
    cdetails char(255) NOT NULL,
    postcode char(10) NOT NULL,
    cphone char(20) NOT NULL,
    cspecial char(20) NOT NULL,
    cmail char(30) NOT NULL,
    csite char(50) NOT NULL,
    eurl char(50) NOT NULL
);
INSERT INTO company
VALUES("摩托车建站（国际）有限公司", "汽车建站是德国历史最悠久的汽车制造商之一。其高技术水平、高质量标准以及高强劲动力的准则，让汽车建站品牌成为国际著名豪华汽车的标志。不仅如此，随着时代的不断进步，汽车建站品牌越来越多的出现在我们的生活当中，给予我们更为时尚的运动基因，同时还坚持以绿色节能减排环保战略为出发点，为社会贡献出自己的一份力量。", "邮编：400000", "手机：13452241231", "电话：023-0000000", "邮箱：872907682@qq.com", "地址：中国重庆市渝北区新牌坊长安锦绣城", "code.jpg");

-- 门店表
create table shop
(
    shopname char(50) NOT NULL,
    sphone char(20) NOT NULL,
    sname char(50) NOT NULL,
    smail char(30) NOT NULL
);
INSERT INTO shop
VALUES("重庆渝北总部", "咨询电话：13452241231", "联系人：张先生", "电子邮箱：872907682@qq.com");
INSERT INTO shop
VALUES("重庆渝中分店", "咨询电话：13452241231", "联系人：张先生", "电子邮箱：872907682@qq.com");
INSERT INTO shop
VALUES("重庆江北分店", "咨询电话：13452241231", "联系人：张先生", "电子邮箱：872907682@qq.com");
INSERT INTO shop
VALUES("重庆南坪分店", "咨询电话：13452241231", "联系人：张先生", "电子邮箱：872907682@qq.com");

-- 预约表
create table appoint
(
    id int
    unsigned PRIMARY KEY auto_increment,
    aname char
    (50),
    aphone char
    (50),
    acar char
    (50),
    atime date,
    amail char
    (30),
    asite char
    (80)
);

    -- 用户表
    CREATE TABLE users
    (
        id int
        unsigned PRIMARY KEY auto_increment,
    uname CHAR
        (20) UNIQUE NOT NULL,
    unick CHAR
        (10) NOT NULL,
    email CHAR
        (30) NOT NULL,
    upwd VARCHAR
        (255) NOT NULL
);
        INSERT INTO users
        VALUES(NULL, 'boos', 'boos', 'boos@163.com', 'boos
');

        -- 商品表
        create table product
        (
            id int
            unsigned PRIMARY KEY auto_increment,
    pname char
            (50) NOT NULL,
    price double NOT NULL,
    pdetails varchar
            (1000) NOT NULL,
    plimage varchar
            (1000) NOT NULL,
    pdetsimage varchar
            (1000) NOT NULL
);
            INSERT INTO product
            VALUES(NULL, "印第安 首领 黑马 CHIEFTAIN DARK HORSE", 419800, "<div>印第安 首领 黑马 CHIEFTAIN DARK HORSE</div><div class='content_det_wire details_div'></div><div>生而无畏，本当如此</div><div>Indian® Chieftain Dark Horse® 具有攻击性的设计风格，多种磨砂涂装可选，酷黑风格的Thunder Stroke® 111发动机，让你与众不同，在人群中脱颖而出。</div><div>¥419800</div>", "[0e577499bb301f9e1f352167969b0e11.png,b6d92792ee6235678fa57441bcfd451a.png,6dcf04d4f3a20a21c84fcd1330e52c7f.png,0d52c32733a6b7fe11e7277a170a17b6.png,677eefcbc7a4e408e9b7ba8c04800ef1.png,5a4840f66b279c8be2d0e4ae920b311b.png,272a96e5d6a6ebb50b3a19719dc96363.png]", "[01ae3c8c16d92c72469f5a853967f6e5.jpg,f0e528700e9dc1f67ca9cef79736a7e8.jpg,60283a59af5ded9ae939c12c326bce5e.jpg,982ad2bfd964bf899b40733513a42a50.jpg,ce627c846afbd881ba50d15fa9521b81.jpg]");
            INSERT INTO product
            VALUES(NULL, "印第安 首领 限量 CHIEFTAIN Limited", 429800, "<div>印第安 首领 限量 CHIEFTAIN Limited</div><div class='content_det_wire details_div'></div><div>身先士卒，一马当先</div><div>Indian® Chieftain® Limited采用了流线型的设计、更加激进的风格，加入了更多高级功能、再加上独一无二的Thunder Stroke® 111发动机。谨以此献给天生的领袖、无畏的勇士、追求卓越的强者！</div><div>¥429800</div>", "[3db60f8698d3c176cc2f033531e13065.png,2b3df7d8449dcd8a103c1664065527dc.png,47f92eb431bbd43709d632913bd37196.png,2e861e4f1ee5892aabd7c82e6268ca27.png,d538837dca152fa8a42f9256d9ad43fd.png]", "[181045e449aac251cbf2ccf67bddeae2.jpg,92284c5d2f584c913f65db035449008e.jpg,c0a7f609266691e45596212a92078f5f.jpg,0c933c200abcfa295e7118f9a20d14d4.jpg,31c72e1e63e5da7d646a11ca17de5561.jpg]");
            INSERT INTO product
            VALUES(NULL, "印第安 首领 经典 CHIEFTAIN CLASSIC", 419800, "<div>印第安 首领 经典 CHIEFTAIN CLASSIC</div><div class='content_det_wire details_div'></div><div>勿忘来路，一往直前</div><div>经典不会随着时间的推移而黯然失色，Indian® Chieftain® Classic结合了传统的美式设计和全新的高级功能、以及独一无二的性能表现，打造出了一款标志性的经典美式巡航摩托车。</div><div>¥419800</div>", "[399bbed4df3a255037e928b14f4013f8.png,144f357512dfbc01933378bd31dffbae.png,829c93785a41dc60621704dbb39291b7.png,d244648a95386c064499e6e17a74c352.png,d21f9b64178bcdaf0e562a52cf83766e.png,cc876b03ce0da0f11facbd08028a8558.png,0dc9bde8be84ae5a9361d98a8bd2f137.png]", "[774da477ff1c50aa4c4332dab90a91f6.jpg,dd6076308375d640d90c36b046842a00.jpg,796387b1a23f81a1eccd0227e895a6e0.jpg]");
            INSERT INTO product
            VALUES(NULL, "印第安SCOUT BOBBER 20 SCOUT BOBBER TWENTY", 196800, "<div>印第安SCOUT BOBBER 20 SCOUT BOBBER TWENTY</div><div class='content_det_wire details_div'></div><div>怀旧经典，复古情怀</div><div>Scout®Bobber Twenty 是一款怀旧车型，以初代印第安侦察兵为设计灵感，适合传承标志性经典款式的骑士。</div><div>¥196800</div>", "[7b01fa6bd846b712cf1ccdbaf779947d.png,d038749348188f319a1e30bd4751e892.png,15901318c77e0faf7c7163e78887f3e0.png,69f2dbaa17536ac7368d976d4b4bc876.png,3766e7e6d805e8a8d1624d741475094f.png,df4b96a90d74cdb526f58bf67215c84e.png,10701cab64858c6785632fe8e2d0ea22.png]", "[8c16cbc2235d942de76f32b06762e271.jpg,b69ce9f065de53c22b883d4f1681dd4e_710x460x90.jpg,a4cf6cd79d348cd7aab5078c5914366d_710x460x90.jpg,6d3726b4857e4089676c81f67b90a2ff_540x350x90.jpg,f5ad47cecff8a8ee1d489a1537445b64_880x350x90.jpg]");
            INSERT INTO product
            VALUES(NULL, "印第安 领地 黑马 SPRINGFIELD DARK HORSE", 329800, "<div>印第安 领地 黑马 SPRINGFIELD DARK HORSE</div><div class='content_det_wire details_div'></div><div>不容忽视，号令群雄</div><div>Indian® Springfield Dark Horse® 充满了态度，并加装了高配性能。Thunder Stroke® 111发动机更为您提供了更振奋人心的动力。</div><div>¥329800</div>", "[ce38f89251255d37d8401ff74144846e.png,3a16d7f60095196b6a7c77dedc9ef5e8.png,932c4911b04eaa588d22062ad914cd2b.png,a54c6b4408b21d993bf870338d2e075a.png,dda3a0045fcb7c5482f3f0ae9f89d5ff.png]", "[cc12005128abd6f1ac6f1e82807699a7.jpg,a3d358127716994c47e685b18f103dbf.jpg,d8e67f2697c240978116ad45b5b7b4a2.jpg]");
            INSERT INTO product
            VALUES(NULL, "FTR 拉力版 FTR RALLY", 207800, "<div>FTR 拉力版 FTR RALLY</div><div class='content_det_wire details_div'></div><div>复古回潮，制霸街区</div><div>FTR将最受欢迎的拉力风格变成标配，兼具复古外形与现代动力，不管是在城市街头，或是外出骑行，FTR RALLY都会让你如鱼得水。</div><div>¥207800</div>", "[2e2c212b094b3d1cb696448af6dd8723.jpg,c077480bc9b855aab98bd1d35f5a6850.jpg,10ca85013a9bcd1707839e9e772a7bc6.jpg,f2da1b0002610978c1d82e8a3799c368.jpg,4b350aecfce297c0ab97b61133841936.jpg,bccb8e45ff1cdb8be5a0e02200dd1ce2.jpg,fe790cc40dcdb65d8f9d300f3402fd5b.jpg]", "[bf5bbdc3dad6a004d5157cf23391216d.jpg,4627f6ceef3e4b6a9f60a42b3222461f.jpg,fd8af4ce7cbc6fa61959c824b86ce658.jpg,7979976f5441209eae7f3763339ec53b.jpg,d6be9a50cd8b41695522da666f8233f1.jpg]");
            INSERT INTO product
            VALUES(NULL, "印第安 公路大师 黑马 ROADMASTER DARK HORSE", 488000, "<div>印第安 公路大师 黑马 ROADMASTER DARK HORSE</div><div class='content_det_wire details_div'></div><div>酷黑势力，无惧远征</div><div>新款Indian® Roadmaster Dark Horse® 比以往更加个性化。除了冷酷的外观，还配备了一系列豪华的高级功能，以及涂黑的Thunder Stroke® 111发动机，带来强劲动力。</div><div>¥488000</div>", "[53a8e126d407eed1ef3fe20f5fc72cbe.png,dd2d68c7439265727fbf7a104edb6a2e.png,f948d377afc54077b0b4362e7a05b232.png,648c3d391fc011dc82b65ab79798c273.png,2d63aa815b53a08138784857e48a75ee.png]", "[eacefcf7da91d6a856cd7fc2ae64aedf.jpg,feeb4575c94227599f886b3310a50a35.jpg,f8bcd56749085ca9c0959bf0ff3433f0.jpg,577a264edd2d1f7bbbf6202e02b2057b.jpg,d68c66eaa459c691ab01a6e89fd8d18e.jpg]");
            INSERT INTO product
            VALUES(NULL, "FTR碳纤维版 FTR CARBON", 218000, "<div>FTR碳纤维版 FTR CARBON</div><div class='content_det_wire details_div'></div><div>高碳生活，从此开始</div><div>作为印第安摩托在街车平台的心血之作，FTR 1200系列一问世便受到全世界骑士的欢迎。FTR CARBON更是集所有高级配置于一身，标志性的FTR冠军红色车架、大面积碳纤维车身 ......印第安再一次重设了美式机车的上限！</div><div>¥218000</div>", "[3d8a9637b786fc92dd92a0f41265448c.png,fc46213a10686ea248b5f0a5e31d0ff1.png,602637bd462e42d422a3d5a87eb76ec5.png,361f76c5eddac38074cbce4f2c4756fd.png,58fc54e008ae3fb45c2c10b65f21b434.png,7e4ce5053f3f6f2bd009a45e5be7783f.png,62e91195a6c99227d054851a7578a7d9.png]", "[33c5037de20d077ed540275cb68058a4.jpg,08cfb2fbce415e52d6c53c7bb39a6b97.jpg,6aabd1d463e27eb30b8dcd8de0d09cb6.jpg,d3ccd57d3d54a53fd2548494721876b0.jpg,1f50a907b6ed7663629f567cd51a229f.jpg]");
            INSERT INTO product
            VALUES(NULL, "印第安SCOUT BOBBER SCOUT BOBBER", 176800, "<div>印第安SCOUT BOBBER SCOUT BOBBER</div><div class='content_det_wire details_div'></div><div>摈弃浮华，永不妥协</div><div>极简及酷黑风格，Scout®Bobber以其进击的姿态，以及1133cc, 82Nm/52kW功率的V型双缸发动机，宣告着我们永不妥协，而拥有它的你，也将勇往直前。</div><div>¥176800</div>", "[35445693ebce4339c15839e5cc3bc8af.png,4f5dfcb561f4ea45aeb0484e7bf0b9ef.png,e46efabccaa5dba3cea38ea05d001798.png,ac0ec95685bec808714be9789a0bf532.png,1adeceb1ae8ff50bd90df3cd068e9083.png,1cf0c09f665535b96ee08e53745f1390.png,81d63ea67b606f832feef2fed7448afb.png]", "[d6fe7fdc127c21cd7e56e2957b42a686.jpg,84113c677b96d7c3315ff54623b18e1d.jpg,271867733d83fc6019b2be0585dd2cb3.jpg,1aa48a43246378d0b6f081e9537c4fd0.jpg,bdc1caf2c91d1f1b852e9fc5b8d6e702.jpg]");

            --购物车表
            create table shopping
            (
                id int
                unsigned PRIMARY KEY auto_increment,
    sname char
                (50) NOT NULL,
    num SMALLINT unsigned NOT NULL DEFAULT 0,
    sprice double NOT NULL,
    ischecked TINYINT
                (1),
    users_id int unsigned NOT NULL,
    product_id int unsigned NOT NULL,
    FOREIGN KEY
                (users_id) REFERENCES users
                (id),
    FOREIGN KEY
                (product_id) REFERENCES product
                (id)
);