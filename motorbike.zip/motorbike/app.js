const express = require("express");
const server = express();
const cors = require("cors");
const bodyParser = require("body-parser");
server.use(
  cors({
    origin: ["http://127.0.0.1:8080", "http://localhost:8080"],
  })
);
server.use(
  bodyParser.urlencoded({
    extended: false,
  })
);
//连接池
const mysql = require("mysql");
const pool = mysql.createPool({
  host: "127.0.0.1",
  port: 3306,
  user: "root",
  password: "",
  database: "motorbike",
  charset: "utf8",
});
//用户注册接口
server.post("/register", (req, res) => {
  let uname = req.body.uname;
  let unick = req.body.unick;
  let email = req.body.umail;
  let upwd = req.body.upwd;
  console.log(upwd);
  console.log(uname);
  let sql = "SELECT COUNT(id) AS count FROM users WHERE uname=?";
  pool.query(sql, [uname], (err, results) => {
    if (results[0].count) {
      res.send({ message: "注册失败", code: 0 });
    } else {
      // let sql = "INSERT users(uname,unick,email,upwd) VALUES(?,?,?,MD5(?))";
      let sql = "INSERT users VALUES(null,?,?,?,?)";
      pool.query(sql, [uname, unick, email, upwd], (err, results) => {
        if (err) throw err;
        res.send({ message: "注册成功", code: 1 });
      });
    }
  });
});
//用户登录接口
server.post("/login", (req, res) => {
  let uname = req.body.uname;
  let upwd = req.body.upwd;
  let sql = "SELECT id,uname,unick FROM users WHERE uname=? AND upwd=?";
  pool.query(sql, [uname, upwd], (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "登录成功", code: 1, results: results[0] });
    } else {
      res.send({ message: "登录失败", code: 0 });
    }
  });
});
//获取新闻内容接口
server.get("/journalism", (req, res) => {
  let sql = "select*from news";
  pool.query(sql, (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "获取失败", code: 0 });
    }
  });
});
//获取底部公司信息接口
server.get("/we", (req, res) => {
  let sql = "select*from company";
  pool.query(sql, (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "获取失败", code: 0 });
    }
  });
});
//获取车展图片url接口
server.get("/car", (req, res) => {
  let sql = "select*from url";
  pool.query(sql, (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "获取失败", code: 0 });
    }
  });
});
//获取门店信息
server.get("/shop", (req, res) => {
  let sql = "select*from shop";
  pool.query(sql, (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "获取失败", code: 0 });
    }
  });
});
//获取用户预约表
server.post("/appoint", (req, res) => {
  let uname = req.body.uname,
    uphone = req.body.uphone,
    ucar = req.body.ucar,
    value2 = req.body.value2,
    umail = req.body.umail,
    usite = req.body.usite;
  let sql = "INSERT INTO appoint VALUES(null,?,?,?,?,?,?)";
  pool.query(
    sql,
    [uname, uphone, ucar, value2, umail, usite],
    (err, results) => {
      if (err) throw err;
      res.send({ message: "注册成功", code: 1 });
    }
  );
});
//获取所有商品信息
server.get("/product", (req, res) => {
  let sql = "select*from product";
  pool.query(sql, (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "获取失败", code: 0 });
    }
  });
});
//获取对应id商品信息
server.get("/details", (req, res) => {
  let id = req.query.id;
  let sql = "select*from product where id=?";
  pool.query(sql, [id], (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "获取失败", code: 0 });
    }
  });
});
//获取用户购物车信息
server.get("/sopping", (req, res) => {
  let id = req.query.id;
  let sql =
    "SELECT sname,num,sprice,ischecked,product_id FROM users AS a INNER JOIN shopping AS u ON users_id=a.id WHERE a.id=?";
  pool.query(sql, [id], (err, results) => {
    if (err) throw err;
    if (results.length) {
      res.send({ message: "获取成功", code: 1, results: results });
    } else {
      res.send({ message: "数组为空", code: 0 });
    }
    // if (results.length) {
    //   res.send({ message: "获取成功", code: 1, results: results });
    // } else {
    //   res.send({ message: "获取失败", code: 0 });
    // }
  });
});
//添加购物车商品
server.get("/addCar", (req, res) => {
  let product_id = req.query.sid,
    sname = req.query.sname,
    sprice = req.query.price,
    users_id = req.query.uid;
  let num = "";
  //控制查询结果有则修改否则新增
  let isBut = true;
  let sql1 =
    "SELECT sname,num,sprice,ischecked FROM users AS a INNER JOIN shopping AS u ON users_id=a.id WHERE a.id=?";
  pool.query(sql1, [users_id], (err, results) => {
    for (let item of results) {
      if (item.sname === sname) {
        isBut = false;
        num = item.num + 1;
        let sql3 = "UPDATE shopping SET num=? WHERE product_id=?;";
        pool.query(sql3, [num, product_id], (err, results) => {
          if (err) throw err;
          res.send({ message: "添加成功", code: 1 });
        });
      }
    }
    if (isBut) {
      let sql2 = "INSERT INTO shopping VALUES(null,?,1,?,?,?,?);";
      pool.query(
        sql2,
        [sname, sprice, true, users_id, product_id],
        (err, results) => {
          if (err) throw err;
          res.send({ message: "添加成功", code: 1 });
        }
      );
    }
  });
});
//删除购物车商品
server.get("/remove", (req, res) => {
  let product_id = req.query.product_id;
  let users_id = req.query.users_id;
  let sql = "DELETE FROM shopping WHERE product_id=? AND users_id=?";
  pool.query(sql, [product_id, users_id], (err, results) => {
    if (err) throw err;
    res.send({ message: "删除成功", code: 1, results: results });
    // if (results.length) {
    //   res.send({ message: "删除成功", code: 1, results: results });
    // } else {
    //   res.send({ message: "删除失败", code: 0 });
    // }
  });
});
//修改购物车商品
server.get("/updata", (req, res) => {
  let product_id = req.query.product_id;
  let num = parseInt(req.query.num);
  let users_id = req.query.users_id;
  let sql = "SELECT num FROM shopping WHERE product_id=? AND users_id=?";
  pool.query(sql, [product_id, users_id], (err, results) => {
    if (err) throw err;
    number = results[0].num + num;
    let sql = "UPDATE shopping SET num=? WHERE product_id=? AND users_id=?;";
    pool.query(sql, [number, product_id, users_id], (err, results) => {
      if (err) throw err;
      res.send({ message: "修改成功", code: 1, results: results });
    });
  });
});
server.listen(3000);
