import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    //网页页面布局
    iswidth: "",
    isMdwidth: "",
    slideshow_height: "",
    slideshow: "",
    //登录状态
    login: sessionStorage.getItem("login") || false,
    son: "",
  },
  mutations: {
    //登录
    isLogin(state, login) {
      state.login = login;
    },
    upWidth(state, iswidth) {
      state.iswidth = iswidth;
    },
    upWidth2(state, isMdwidth) {
      state.isMdwidth = isMdwidth;
    },
    slideshowHeight(state, slideshow_height) {
      state.slideshow_height = slideshow_height;
    },
    slideshow(state, isSlideshow) {
      state.isSlideshow = isSlideshow;
    },
    isMar(state, slideshow) {
      state.slideshow = slideshow;
    },
    upSon(state, son) {
      state.son = son;
    },
  },
  actions: {},
  modules: {},
});
