<template>
    <div>
    <!-- md导航 -->
    <el-row class="phone_nav" v-if="this.isMdwidth">
        <el-col class="phone_nav_img">
        <img class="phone_nav_logo" src="../assets/home/logocar.png">
        <img @click="more" class="phone_nav_more" v-if="this.isMore" src="../assets/home/more.png">
        <img @click="more" class="phone_nav_more_on" v-else src="../assets/home/more_on.png">
        <div class="phone_nav_more_con" v-if="this.isMore">
          <img class="phone_nav_logo" src="../assets/home/logocar.png">
          <img @click="more" class="phone_nav_more" v-if="this.isMore" src="../assets/home/more.png">
          <img @click="more" class="phone_nav_more_on" v-else src="../assets/home/more_on.png">
          <div class="phone_more_nav">
            <el-col :xs="24">
              <router-link to="/">首页</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">产品</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">新闻</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">车展</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">我们</router-link>
                        </el-col><br><hr>
                    </div>
                </div>
            </el-col>
        </el-row>
        <!-- lg导航 -->
        <el-container>
          <el-header id="nav" v-if="iswidth" class="herder_logo">
            <el-row :gutter="20">
              <el-col :md="5">
                <img class="herder_img" src="../assets/home/logocar.png">
              </el-col>
              <el-col :md="16" class="herder_nav">
                  <el-col :md="2">
                    <router-link to="/">首页</router-link>
                  </el-col>
                  <el-col :md="2">
                    <router-link to="/product">产品</router-link>
                  </el-col>
                  <el-col :md="2">
                    <router-link to="/journalism">新闻</router-link>
                  </el-col>
                  <el-col :md="2">
                    <router-link to="/car">车展</router-link>
                  </el-col>
                  <el-col :md="2">
                    <router-link to="/we">我们</router-link>
                  </el-col>
              </el-col>
              <el-col class="herder_nav" :md="3">
                <a class="herder_login" href="/">登录</a>
                <div class="herder_login">/</div>
                <a class="herder_login" href="/">注册</a>
              </el-col>
            </el-row>
            <div class="bg a"></div>
          </el-header>
        </el-container>
    <div class="product" :style="this.image"></div>
        <div class="product_content">
            



            <div class="content_det_wire"></div>
                <el-row class="content_end">
                <el-col :xs="24" :md="16">
                    <el-col class="content_end_my" :xs="24">联系我们</el-col>
                    <el-col class="content_end_my_con" :xs="24" :md="12">邮编：400000</el-col>
                    <el-col class="content_end_my_con" :xs="24" :md="12">手机：13452241231</el-col>
                    <el-col class="content_end_my_con" :xs="24" :md="12">电话：023-0000000</el-col>
                    <el-col class="content_end_my_con" :xs="24" :md="12">邮箱：872907682@qq.com</el-col>
                    <el-col class="content_end_my_con" :xs="24">地址：中国重庆市渝北区新牌坊长安锦绣城</el-col>
                    <el-col class="content_end_my" :xs="24">
                    <img class="content_end_my_iconfont" src="../assets/home/xinlang.png">
                    <img class="content_end_my_iconfont" src="../assets/home/gongzhonghao.png">
                    <img class="content_end_my_iconfont" src="../assets/home/qq.png">
                    </el-col>
                </el-col>
                <el-col class="content_end_my" :xs="24" :md="8">关注我们</el-col>
                <el-col class="content_end_my_code" :xs="24" :md="8">
                    <img class="content_end_my_code_font" src="../assets/home/code.jpg">
                    <div style="padding-top:10px">微信公众号</div>
                </el-col>
                </el-row>
        </div>        
    </div>
</template>
<script>
export default {
  data(){
    return {
      image:{backgroundImage:"url("+require('../assets/home/870_w2000.jpg')+")"},
      //pc端导航显示
      iswidth:true,
      //手机屏幕下的导航显示
      isMdwidth:false,
      Img:[
        {backgroundImage:"url("+require('../assets/home/3917_j5sxsdco.jpg')+")"},
        {backgroundImage:"url("+require('../assets/home/1265_w2000.jpg')+")"},
        {backgroundImage:"url("+require('../assets/home/2722_w2000.jpg')+")"}
      ],
      //导航栏更多状态
      isMore:false,
      //可视界面宽度
      webWidth:document.body.clientWidth,
      //轮播图
      slideshow:"margin-top: -70px;",
      slideshow_height:"1166px",
      isSlideshow:70
    }
  },
  methods:{
    more(){
      this.isMore=!this.isMore;
    },
    md(){
      this.iswidth=false;
      this.isMdwidth=true;
      this.slideshow="margin-top: 47px;";
    },
    lg(){
      this.iswidth=true;
      this.isMdwidth=false;
      this.slideshow=`margin-top: ${this.isSlideshow}px;`;
    }
  },
  watch:{
    webWidth(){
      if(this.webWidth<=992){
        this.md();
      }else{
        this.lg();
      }
    }
  },
  mounted(){
    window.onresize=()=>{
      this.webWidth=document.body.clientWidth;
      this.slideshow_height=(this.webWidth/1.64)-47+"px";
      this.isSlideshow=-(this.webWidth/27.3);
    }
    window.onscroll=function(){
      let scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
      let toTop=document.getElementById("nav");
      this.webWidth=document.body.clientWidth;
      if(this.webWidth>=992){
        if(scrollTop==0){
          toTop.style.backgroundColor= "transparent";
        }else{ 
          toTop.style.backgroundColor= "#000";
        }
      }
    }
  },
}
</script>