<template>
  <div>
    <!-- md导航 -->
    <el-row class="phone_nav" v-if="this.isMdwidth">
      <el-col class="phone_nav_img">
        <img class="phone_nav_logo" src="../assets/home/logocar.png">
        <img @click="more" class="phone_nav_more" v-if="this.isMore" src="../assets/home/more.png">
        <img @click="more" class="phone_nav_more_on" v-else src="../assets/home/more_on.png">
        <div class="phone_nav_more_con" v-if="this.isMore">
          <img class="phone_nav_logo" src="../assets/home/logocar.png">
          <img @click="more" class="phone_nav_more" v-if="this.isMore" src="../assets/home/more.png">
          <img @click="more" class="phone_nav_more_on" v-else src="../assets/home/more_on.png">
          <div class="phone_more_nav">
            <el-col :xs="24">
              <router-link to="/">首页</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">产品</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">新闻</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">车展</router-link>
            </el-col><br><hr>
            <el-col :xs="24">
              <router-link to="/">我们</router-link>
            </el-col><br><hr>
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- 轮播图 -->
    <el-carousel :style="slideshow" trigger="click" :height="slideshow_height">
      <el-carousel-item v-for="(item,i) in image" :key="i">
          <img class="dom_bg" :src="item">
      </el-carousel-item>
    </el-carousel>
        <!-- lg导航 -->
        <el-container>
          <el-header id="nav" v-if="iswidth" class="herder_logo">
            <el-row :gutter="20">
              <el-col :md="5">
                <img class="herder_img" src="../assets/home/logocar.png">
              </el-col>
              <el-col :md="16" class="herder_nav">
                  <el-col :md="2"><a href="/">首页</a></el-col>
                  <el-col :md="2"><a href="/">产品</a></el-col>
                  <el-col :md="2"><a href="/">新闻</a></el-col>
                  <el-col :md="2"><a href="/">车展</a></el-col>
                  <el-col :md="2"><a href="/">我们</a></el-col>
              </el-col>
              <el-col class="herder_nav" :md="3">
                <a class="herder_login" href="/">登录</a>
                <div class="herder_login">/</div>
                <a class="herder_login" href="/">注册</a>
              </el-col>
            </el-row>
            <div class="bg a"></div>
          </el-header>
        </el-container>
        <!-- 内容部分 -->
        <div class="content">
          <div class="content_logo">
            <img class="content_logo_img" src="../assets/home/3917_j5nnw4bg.png">
          </div>
          <div class="content_logo_font">最时尚炫酷的产品，最安全可靠的渠道</div>
          <el-row>
            <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img" src="../assets/home/0e577499bb301f9e1f352167969b0e11.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">Indian® Chieftain Dark Horse® </div>
                  <div class="content_new_padd">￥419800.00</div>
                </div>
            </el-col>
            <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img" src="../assets/home/3db60f8698d3c176cc2f033531e13065.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">Indian® Chieftain® Limited</div>
                  <div class="content_new_padd">￥429800.00</div>
                </div>
            </el-col>
            <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img" src="../assets/home/399bbed4df3a255037e928b14f4013f8.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">Indian® Chieftain® Classic</div>
                  <div class="content_new_padd">￥19800.00</div>
                </div>
            </el-col>
        </el-row>
          <div class="content_my">
            <img class="content_logo_img" src="../assets/home/3917_j85pjaoi.png">
            <div class="content_logo_font">最时尚炫酷的产品，最安全可靠的渠道</div>
          </div>
          <el-row class="content_my_buttom">
            <el-col :xs="24" :md="12">
              <video width="583px" height="313px" autoplay controls muted loop src="../assets/home/halei(3038826).mp4"></video>
            </el-col>
            <el-col class="content_my_wen" :xs="24" :md="12">
              <p class="content_my_wen_tit">摩托车建站（国际）有限公司</p>
              <p class="content_my_wen_zi">汽车建站是德国历史最悠久的汽车制造商之一。其高技术水平、高质量标准以及高强劲动力的准则，让汽车建站品牌成为国际著名豪华汽车的标志。不仅如此，随着时代的不断进步，汽车建站品牌越来越多的出现在我们的生活当中，给予我们更为时尚的运动基因，同时还坚持以绿色节能减排环保战略为出发点，为社会贡献出自己的一份力量。</p>
              <router-link to="/" class="content_my_wen_a">了解更多</router-link>
            </el-col>
           </el-row>
           <div class="content_my_bg" :style="Img[0]">
             <div class="content_my_over">
               <div class="content_my_over_top">速度是心跳的<span style="color:rgb(224,10,10);">开始</span></div>
               <div class="content_my_over_center">一个从未尝试冒险过的人，必然是一个失败的人，只要能执着远大的理想，且有不达目的绝不终止的意愿，</div>
               <div class="content_my_over_center">便能产生惊人的力量。</div>
               <div class="content_my_over_bottom">
                <router-link to="/" class="content_my_wen_a">立即体验</router-link>
               </div>
             </div>
            </div>
            <div class="content_logo">
              <img src="../assets/home/3917_j85pjxk6.png" class="content_logo_img">
              <div class="content_logo_font_new">最时尚炫酷的产品，最安全可靠的渠道</div>
            </div>
            <el-row class="content_new_paddTop">
              <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img " src="../assets/home/7b01fa6bd846b712cf1ccdbaf779947d.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">Scout®Bobber Twenty </div>
                  <div class="content_new_padd">￥196800.00</div>
                </div>
              </el-col>
               <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img " src="../assets/home/ce38f89251255d37d8401ff74144846e.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">ndian® Springfield Dark Horse®</div>
                  <div class="content_new_padd">￥329800.00</div>
                </div>
              </el-col>
               <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img " src="../assets/home/2e2c212b094b3d1cb696448af6dd8723.jpg" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">FTR 拉力版</div>
                  <div class="content_new_padd">￥207800.00</div>
                </div>
              </el-col>
               <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img " src="../assets/home/53a8e126d407eed1ef3fe20f5fc72cbe.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">Indian® Roadmaster Dark Horse®</div>
                  <div class="content_new_padd">￥488000.00</div>
                </div>
              </el-col>
              <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img " src="../assets/home/3d8a9637b786fc92dd92a0f41265448c.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">FTR CARBON</div>
                  <div class="content_new_padd">￥218000.00</div>
                </div>
              </el-col>
              <el-col :xs="24" :md="12" :lg="8" class="content_new_rel">
                <img class="content_new_img " src="../assets/home/35445693ebce4339c15839e5cc3bc8af.png" alt="">
                <div class="content_new_but">
                  <div class="content_new_padd">Scout®Bobber</div>
                  <div class="content_new_padd">￥176800.00</div>
                </div>
              </el-col>
            </el-row>
            <el-row>
              <el-col :xs="24" :lg="12" class="content_new_ove">
                <div :style="Img[1]" class="content_new_bg">
                  <div class="content_new_bg_lucency">
                    <div class="content_new_bg_tit">全手工机械机车系列</div>
                    <div class="content_new_bg_cen">精致外观+经济性能</div>
                    <div>
                      <router-link to="/" class="content_my_wen_a content_new_bg_a">了解更多</router-link>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :xs="24" :lg="12" class="content_new_ove">
                <div :style="Img[2]" class="content_new_bg">
                  <div class="content_new_bg_lucency">
                    <div class="content_new_bg_tit">高端赛车手配置机车系列</div>
                    <div class="content_new_bg_cen">精致外观+经济性能</div>
                    <div>
                      <router-link to="/" class="content_my_wen_a content_new_bg_a">了解更多</router-link>
                    </div>
                  </div>
                </div>
              </el-col>
            </el-row>
            <div class="content_logo">
              <img src="../assets/home/3917_j85plyg8.png"  class="content_logo_img">
              <div class="content_logo_font">最时尚炫酷的产品，最安全可靠的渠道</div>
            </div>
            <div class="content_det">
              <router-link to="/" class="content_logo__a">
                <div class="content_det_sty">
                  <div class="content_det_font_tit">融入更多新元素，哈雷STREET ROD</div>
                  <div class="content_det_font_cen">在三月份，哈雷全新推出了STREET ROD，这辆新车不仅让人想到了此前的STREET 750，而且从前些天哈雷公布的官方售价看，98888元的STREET ROD要比STREET 750在国内高出1万块，有人不禁要问了，这俩车发动机如此相似到底是不是STREET 750换了个壳？</div>
                </div>
              </router-link>
            </div>
            <div class="content_det">
              <router-link to="/" class="content_logo__a">
                <div class="content_det_sty">
                  <div class="content_det_font_tit">清凉薄荷味的戴维森 Street Road 750 ROD</div>
                  <div class="content_det_font_cen">这辆改装车是由HD Street 750 改装而来，奥地利车行NCT Motorcycles 在从哈雷经销商那里接到这辆新车时，对方告知他们预算和时间都非常有限，因为改装成品将会在今年九月初的European Bike Week聚会上当作抽奖奖品，这个活动今年在奥地利举行，是欧洲地区哈雷车主的年度例行盛事，今年刚好满20周年。</div>
                </div>
              </router-link>  
            </div>
            <div class="content_det_wire"></div>
            <el-row class="content_end">
              <el-col :xs="24" :md="16">
                <el-col class="content_end_my" :xs="24">联系我们</el-col>
                <el-col class="content_end_my_con" :xs="24" :md="12">邮编：400000</el-col>
                <el-col class="content_end_my_con" :xs="24" :md="12">手机：13452241231</el-col>
                <el-col class="content_end_my_con" :xs="24" :md="12">电话：023-0000000</el-col>
                <el-col class="content_end_my_con" :xs="24" :md="12">邮箱：872907682@qq.com</el-col>
                <el-col class="content_end_my_con" :xs="24">地址：中国重庆市渝北区新牌坊长安锦绣城</el-col>
                <el-col class="content_end_my" :xs="24">
                  <img class="content_end_my_iconfont" src="../assets/home/xinlang.png">
                  <img class="content_end_my_iconfont" src="../assets/home/gongzhonghao.png">
                  <img class="content_end_my_iconfont" src="../assets/home/qq.png">
                </el-col>
              </el-col>
              <el-col class="content_end_my" :xs="24" :md="8">关注我们</el-col>
              <el-col class="content_end_my_code" :xs="24" :md="8">
                <img class="content_end_my_code_font" src="../assets/home/code.jpg">
                <div style="padding-top:10px">微信公众号</div>
              </el-col>
            </el-row>
        </div>
    </div>
</template>
<script>
export default {
  data(){
    return {
      image:[require("../assets/home/3917_j5nn4iw0.jpg"),require("../assets/home/3917_j5nn1kw5.jpg"),require("../assets/home/2722_w2000.jpg")],
      //pc端导航显示
      iswidth:true,
      //手机屏幕下的导航显示
      isMdwidth:false,
      Img:[
        {backgroundImage:"url("+require('../assets/home/3917_j5sxsdco.jpg')+")"},
        {backgroundImage:"url("+require('../assets/home/1265_w2000.jpg')+")"},
        {backgroundImage:"url("+require('../assets/home/2722_w2000.jpg')+")"}
      ],
      //导航栏更多状态
      isMore:false,
      //可视界面宽度
      webWidth:document.body.clientWidth,
      //轮播图
      slideshow:"margin-top: -70px;",
      slideshow_height:"1166px",
      isSlideshow:70
    }
  },
  methods:{
    more(){
      this.isMore=!this.isMore;
    },
    md(){
      this.iswidth=false;
      this.isMdwidth=true;
      this.slideshow="margin-top: 47px;";
    },
    lg(){
      this.iswidth=true;
      this.isMdwidth=false;
      this.slideshow=`margin-top: ${this.isSlideshow}px;`;
    }
  },
  watch:{
    webWidth(){
      if(this.webWidth<=992){
        this.md();
      }else{
        this.lg();
      }
    }
  },
  mounted(){
    window.onresize=()=>{
      this.webWidth=document.body.clientWidth;
      this.slideshow_height=(this.webWidth/1.64)-47+"px";
      this.isSlideshow=-(this.webWidth/27.3);
    }
    window.onscroll=function(){
      let scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
      let toTop=document.getElementById("nav");
      this.webWidth=document.body.clientWidth;
      if(this.webWidth>=992){
        if(scrollTop==0){
          toTop.style.backgroundColor= "transparent";
        }else{ 
          toTop.style.backgroundColor= "#000";
        }
      }
    }
  },
}
</script>
