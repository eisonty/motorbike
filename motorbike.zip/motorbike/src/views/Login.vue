<template>
  <div>
    <!-- md导航 -->
    <el-row class="phone_nav" v-if="this.$store.state.isMdwidth">
      <el-col class="phone_nav_img">
        <img class="phone_nav_logo" src="../assets/home/logocar.png" />
        <img
          @click="more"
          class="phone_nav_more"
          v-if="this.isMore"
          src="../assets/home/more.png"
        />
        <img
          @click="more"
          class="phone_nav_more_on"
          v-else
          src="../assets/home/more_on.png"
        />
        <div class="phone_nav_more_con" v-if="this.isMore">
          <img class="phone_nav_logo" src="../assets/home/logocar.png" />
          <img
            @click="more"
            class="phone_nav_more"
            v-if="this.isMore"
            src="../assets/home/more.png"
          />
          <img
            @click="more"
            class="phone_nav_more_on"
            v-else
            src="../assets/home/more_on.png"
          />
          <div class="phone_more_nav">
            <el-col class="herder_nav" :xs="24">
              <router-link class="herder_login" to="/register"
                >注册</router-link
              > </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/">首页</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/product">产品</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/journalism">新闻</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/car">车展</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/we">我们</router-link> </el-col
            ><br />
            <hr />
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- lg导航 -->
    <el-container>
      <el-header
        id="nav"
        :style="iscolor"
        v-if="this.$store.state.iswidth"
        class="herder_logo"
      >
        <el-row :gutter="20">
          <el-col :md="5">
            <img class="herder_img" src="../assets/home/logocar.png" />
          </el-col>
          <el-col :md="16" class="herder_nav">
            <el-col :md="2">
              <router-link to="/">首页</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/product">产品</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/journalism">新闻</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/car">车展</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/we">我们</router-link>
            </el-col>
          </el-col>
          <el-col class="herder_nav" :md="3">
            <router-link class="herder_login" to="/register">注册</router-link>
          </el-col>
        </el-row>
        <div class="bg a"></div>
      </el-header>
    </el-container>
    <div class="product" :style="this.image"></div>
    <div class="product_content">
      <div class="we_input">
        <div class="Register">用户登录</div>
        <input
          type="text"
          @blur="isUname"
          placeholder="请输入6~12位用户名"
          v-model="uname"
          class="we_input_value Register_input"
          autofocus="autofocus"
        />
        <span v-if="elseUname" class="lohin_font regFont">用户名格式不对</span>
        <input
          type="password"
          @blur="isupwd1"
          placeholder="请输入8~16位密码"
          v-model="upwd1"
          class="we_input_value Register_input"
          @keydown="login"
        />
        <span v-if="elsepwd1" class="lohin_font regFont">密码格式不对</span>
        <button @click="register" class="we_input_but Register_but">
          立即登录
        </button>
      </div>
      <div class="content_det_wire"></div>
      <!-- 底部公司信息 -->
      <el-row class="content_end" v-for="(v, k) of we" :key="k">
        <el-col :xs="24" :md="16">
          <el-col class="content_end_my" :xs="24">联系我们</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.postcode
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12"
            >{{ v.cphone }}1</el-col
          >
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cspecial
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cmail
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24">{{ v.csite }}</el-col>
          <el-col class="content_end_my" :xs="24">
            <img
              class="content_end_my_iconfont"
              src="../assets/home/xinlang.png"
            />
            <img
              class="content_end_my_iconfont"
              src="../assets/home/gongzhonghao.png"
            />
            <img class="content_end_my_iconfont" src="../assets/home/qq.png" />
          </el-col>
        </el-col>
        <el-col class="content_end_my" :xs="24" :md="8">关注我们</el-col>
        <el-col class="content_end_my_code" :xs="24" :md="8">
          <img class="content_end_my_code_font" :src="url" />
          <div style="padding-top:10px">微信公众号</div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      iscolor: "",
      image: {
        backgroundImage: "url(" + require("../assets/home/870_w2000.jpg") + ")",
      },
      //pc端导航显示
      iswidth: true,
      //手机屏幕下的导航显示
      isMdwidth: false,
      //导航栏更多状态
      isMore: false,
      //可视界面宽度
      webWidth: document.body.clientWidth,
      //轮播图
      slideshow: "margin-top: -70px;",
      slideshow_height: "1166px",
      isSlideshow: 70,
      //用户账户
      uname: "",
      elseUname: "",
      //用户密码
      upwd1: "",
      elsepwd1: "",
      but: true,
      //公司信息数据
      we: {},
      //二维码
      url: "",
    };
  },
  methods: {
    isupwd1() {
      let upwd1 = this.upwd1;
      let reg = /^\w{8,16}$/;
      if (reg.test(upwd1)) {
        this.elsepwd1 = false;
        return true;
      } else {
        this.elsepwd1 = true;
        return false;
      }
    },
    isUname() {
      let uname = this.uname;
      let reg = /^\w{6,12}$/;
      if (reg.test(uname)) {
        this.ifUname = true;
        this.elseUname = false;
        return true;
      } else {
        this.ifUname = false;
        this.elseUname = true;
        return false;
      }
    },
    //回车登录
    login() {
      if (event.keyCode == 13) {
        this.register();
      }
    },
    //点击登录
    register() {
      if (this.isUname() && this.isupwd1()) {
        let upwd = this.upwd1;
        upwd = this.$md5(upwd);
        this.axios
          .post("/login", `uname=${this.uname}&upwd=${upwd}`)
          .then((res) => {
            if (res.data.code == 1) {
              let id = res.data.results.id;
              sessionStorage.setItem("id", id);
              this.but = false;
              this.$message({
                message: "登录成功,即将跳转至首页",
                type: "success",
                duration: 2000,
              });
              this.$store.commit("isLogin", true);
              sessionStorage.setItem("login", true);
              setTimeout(() => {
                this.but = true;
                this.$router.push("/");
              }, 3000);
            } else {
              this.$confirm("账户名和密码错误", "温馨提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning",
              });
            }
          });
      }
    },
    more() {
      this.isMore = !this.isMore;
    },
    md() {
      this.iswidth = false;
      this.isMdwidth = true;
      this.slideshow = "margin-top: 47px;";
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
    lg() {
      this.iswidth = true;
      this.isMdwidth = false;
      this.slideshow = `margin-top: ${this.isSlideshow}px;`;
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
  },
  watch: {
    webWidth() {
      if (this.webWidth <= 992) {
        this.md();
      } else {
        this.lg();
      }
    },
  },
  mounted() {
    //组件切换顶部
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    //请求公司信息
    this.axios.get("/we").then((res) => {
      this.we = res.data.results;
      this.url = require(`../assets/home/${this.we[0].eurl}`);
    });
    window.onload = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
      this.$store.commit("slideshowHeight", this.slideshow_height);
    };
    window.onresize = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
    };
    window.onscroll = function() {
      let scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop;
      let toTop = document.getElementById("nav");
      this.webWidth = document.body.clientWidth;
      if (this.webWidth >= 992) {
        if (scrollTop == 0) {
          toTop.style.backgroundColor = "transparent";
        } else {
          toTop.style.backgroundColor = "#000";
        }
      }
    };
  },
};
</script>
