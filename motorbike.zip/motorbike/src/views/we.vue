<template>
  <div>
    <!-- 购物车 -->
    <router-link to="/shopping">
      <img class="gouwu" src="../assets/home/gouwu.png" alt="" />
    </router-link>
    <!-- md导航 -->
    <el-row class="phone_nav" v-if="this.$store.state.isMdwidth">
      <el-col class="phone_nav_img">
        <img class="phone_nav_logo" src="../assets/home/logocar.png" />
        <img
          @click="more"
          class="phone_nav_more"
          v-if="this.isMore"
          src="../assets/home/more.png"
        />
        <img
          @click="more"
          class="phone_nav_more_on"
          v-else
          src="../assets/home/more_on.png"
        />
        <div class="phone_nav_more_con" v-if="this.isMore">
          <img class="phone_nav_logo" src="../assets/home/logocar.png" />
          <img
            @click="more"
            class="phone_nav_more"
            v-if="this.isMore"
            src="../assets/home/more.png"
          />
          <img
            @click="more"
            class="phone_nav_more_on"
            v-else
            src="../assets/home/more_on.png"
          />
          <div class="phone_more_nav">
            <!-- 登录状态 -->
            <el-col :xs="24" class="herder_nav" v-if="this.$store.state.login">
              <img @click="nologin" src="../assets/home/islogin.png" alt="" />
            </el-col>
            <el-col v-else class="herder_nav" :xs="24">
              <router-link class="herder_login" to="/login">登录</router-link>
              <div class="herder_login">/</div>
              <router-link class="herder_login" to="/register"
                >注册</router-link
              > </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/">首页</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/product">产品</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/journalism">新闻</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/car">车展</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/we">我们</router-link> </el-col
            ><br />
            <hr />
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- lg导航 -->
    <el-container>
      <el-header id="nav" v-if="this.$store.state.iswidth" class="herder_logo">
        <el-row :gutter="20">
          <el-col :md="5">
            <img class="herder_img" src="../assets/home/logocar.png" />
          </el-col>
          <el-col :md="16" class="herder_nav">
            <el-col :md="2">
              <router-link to="/">首页</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/product">产品</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/journalism">新闻</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/car">车展</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/we">我们</router-link>
            </el-col>
          </el-col>
          <!-- 登录状态 -->
          <el-col :md="3" class="login_img" v-if="this.$store.state.login">
            <img @click="nologin" src="../assets/home/islogin2.png" alt="" />
          </el-col>
          <el-col v-else class="herder_nav" :md="3">
            <router-link class="herder_login" to="/login">登录</router-link>
            <div class="herder_login">/</div>
            <router-link class="herder_login" to="/register">注册</router-link>
          </el-col>
        </el-row>
        <div class="bg a"></div>
      </el-header>
    </el-container>
    <div class="product" :style="this.image"></div>
    <div class="product_content">
      <div>
        <div class="we_tit">
          <div>联系我们</div>
          <div>CONTACT US</div>
        </div>
        <el-row class="we_content_mar">
          <el-col :xs="24" :md="12" v-for="(v, i) of shop" :key="i">
            <div class="we_content">
              <div>{{ v.shopname }}</div>
              <div>{{ v.sphone }}</div>
              <div>{{ v.sname }}</div>
              <div>{{ v.smail }}</div>
            </div>
          </el-col>
        </el-row>
        <div class="we_tit">
          <div>地理位置</div>
          <div>LOCATION</div>
          <div>
            <!--百度地图容器-->
            <div
              class="map"
              style="width:800px;height:400px;border:#ccc solid 1px;font-size:12px"
              id="map"
            ></div>
            <p style="color:red;font-weight:600">
              <a
                href="http://developer.baidu.com/map/index.php?title=jspopular/guide/introduction"
                style="color:#2f83c7"
                target="_blank"
              ></a>
              <a
                href="http://lbsyun.baidu.com/apiconsole/key?application=key"
                style="color:#2f83c7"
                target="_blank"
              ></a>
            </p>
          </div>
        </div>
        <div>
          <div class="we_tit">
            <div>预约试驾</div>
            <div>MESSAGE</div>
          </div>
          <!-- 用户预约试驾表 -->
          <el-row class="we_input">
            <el-col :xs="24" :md="12" :lg="8">
              <input
                v-model="uname"
                type="text"
                placeholder="姓名"
                class="we_input_value"
              />
            </el-col>
            <el-col :xs="24" :md="12" :lg="8">
              <input
                v-model="uphone"
                type="text"
                placeholder="电话"
                class="we_input_value"
              />
            </el-col>
            <el-col :xs="24" :md="12" :lg="8">
              <input
                v-model="ucar"
                type="text"
                placeholder="试驾车型"
                class="we_input_value"
              />
            </el-col>
            <el-col class="block" :xs="24" :md="12" :lg="8">
              <el-date-picker
                class="time"
                v-model="value2"
                type="datetime"
                placeholder="预约时间"
                align="right"
                :picker-options="pickerOptions"
              >
              </el-date-picker>
            </el-col>
            <el-col :xs="24" :md="12" :lg="8">
              <input
                v-model="umail"
                type="text"
                placeholder="邮箱"
                class="we_input_value"
              />
            </el-col>
            <el-col :xs="24" :md="12" :lg="8">
              <input
                v-model="usite"
                type="text"
                placeholder="地址"
                class="we_input_value"
                @keydown="login"
              />
            </el-col>
            <button class="we_input_but" @click="appoint">立即提交</button>
          </el-row>
        </div>
      </div>
      <div class="content_det_wire"></div>
      <!-- 底部公司信息 -->
      <el-row class="content_end" v-for="(v, k) of we" :key="k">
        <el-col :xs="24" :md="16">
          <el-col class="content_end_my" :xs="24">联系我们</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.postcode
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12"
            >{{ v.cphone }}1</el-col
          >
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cspecial
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cmail
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24">{{ v.csite }}</el-col>
          <el-col class="content_end_my" :xs="24">
            <img
              class="content_end_my_iconfont"
              src="../assets/home/xinlang.png"
            />
            <img
              class="content_end_my_iconfont"
              src="../assets/home/gongzhonghao.png"
            />
            <img class="content_end_my_iconfont" src="../assets/home/qq.png" />
          </el-col>
        </el-col>
        <el-col class="content_end_my" :xs="24" :md="8">关注我们</el-col>
        <el-col class="content_end_my_code" :xs="24" :md="8">
          <img class="content_end_my_code_font" :src="url" />
          <div style="padding-top:10px">微信公众号</div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      //试驾预约表
      uname: "",
      uphone: "",
      ucar: "",
      umail: "",
      usite: "",
      //预约时间
      pickerOptions: {
        shortcuts: [
          {
            text: "今天",
            onClick(picker) {
              picker.$emit("pick", new Date());
            },
          },
          {
            text: "昨天",
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() - 3600 * 1000 * 24);
              picker.$emit("pick", date);
            },
          },
          {
            text: "一周前",
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", date);
            },
          },
        ],
      },
      value1: "",
      value2: "",
      value3: "",
      drawer: false,
      image: {
        backgroundImage: "url(" + require("../assets/home/870_w2000.jpg") + ")",
      },
      //pc端导航显示
      iswidth: true,
      //手机屏幕下的导航显示
      isMdwidth: false,
      Img: [
        {
          backgroundImage:
            "url(" + require("../assets/home/3917_j5sxsdco.jpg") + ")",
        },
        {
          backgroundImage:
            "url(" + require("../assets/home/1265_w2000.jpg") + ")",
        },
        {
          backgroundImage:
            "url(" + require("../assets/home/2722_w2000.jpg") + ")",
        },
      ],
      //导航栏更多状态
      isMore: false,
      //可视界面宽度
      webWidth: document.body.clientWidth,
      //轮播图
      slideshow: "margin-top: -70px;",
      slideshow_height: "1166px",
      isSlideshow: 70,
      //公司信息数据
      we: {},
      //二维码
      url: "",
      //门店信息
      shop: {},
    };
  },
  methods: {
    nologin() {
      this.$store.commit("isLogin", false);
      sessionStorage.removeItem("login");
      sessionStorage.removeItem("id");
      sessionStorage.removeItem("son");
    },
    more() {
      this.isMore = !this.isMore;
    },
    md() {
      this.iswidth = false;
      this.isMdwidth = true;
      this.slideshow = "margin-top: 47px;";
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
    lg() {
      this.iswidth = true;
      this.isMdwidth = false;
      this.slideshow = `margin-top: ${this.isSlideshow}px;`;
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
    //回车提交预约表
    login() {
      if (event.keyCode == 13) {
        this.appoint();
      }
    },
    //点击提交预约表
    appoint() {
      let id = sessionStorage.getItem("id");
      if (id != undefined) {
        if (
          this.uname != "" &&
          this.uphone != "" &&
          this.ucar != "" &&
          this.value2 != "" &&
          this.umail != "" &&
          this.usite != ""
        ) {
          this.axios
            .post(
              "/appoint",
              `uname=${this.uname}&uphone=${this.uphone}&ucar=${this.ucar}&value2=${this.value2}&umail=${this.umail}&usite=${this.usite}&`
            )
            .then((res) => {
              if (res.data.code) {
                this.$confirm("预约成功,望君按时赴约！", "温馨提示", {
                  confirmButtonText: "确定",
                  cancelButtonText: "取消",
                  type: "warning",
                });
              }
            });
        } else {
          this.$confirm("请正确填写预约信息", "温馨提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          });
        }
      } else {
        this.$confirm("请先登录账户", "温馨提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        });
      }
    },
  },
  watch: {
    webWidth() {
      if (this.webWidth <= 992) {
        this.md();
      } else {
        this.lg();
      }
    },
  },
  mounted() {
    //创建和初始化地图函数：
    function initMap() {
      createMap(); //创建地图
      setMapEvent(); //设置地图事件
      addMapControl(); //向地图添加控件
      addMapOverlay(); //向地图添加覆盖物
    }
    function createMap() {
      map = new BMap.Map("map");
      map.centerAndZoom(new BMap.Point(106.522497, 29.599886), 19);
    }
    function setMapEvent() {
      map.enableScrollWheelZoom();
      map.enableKeyboard();
      map.enableDragging();
      map.enableDoubleClickZoom();
    }
    function addClickHandler(target, window) {
      target.addEventListener("click", function() {
        target.openInfoWindow(window);
      });
    }
    function addMapOverlay() {
      var markers = [
        {
          content: "我的备注",
          title: "重庆总部地址",
          imageOffset: { width: 0, height: 3 },
          position: { lat: 29.600298, lng: 106.52242 },
        },
      ];
      for (var index = 0; index < markers.length; index++) {
        var point = new BMap.Point(
          markers[index].position.lng,
          markers[index].position.lat
        );
        var marker = new BMap.Marker(point, {
          icon: new BMap.Icon(
            "http://api.map.baidu.com/lbsapi/createmap/images/icon.png",
            new BMap.Size(20, 25),
            {
              imageOffset: new BMap.Size(
                markers[index].imageOffset.width,
                markers[index].imageOffset.height
              ),
            }
          ),
        });
        var label = new BMap.Label(markers[index].title, {
          offset: new BMap.Size(25, 5),
        });
        var opts = {
          width: 200,
          title: markers[index].title,
          enableMessage: false,
        };
        var infoWindow = new BMap.InfoWindow(markers[index].content, opts);
        marker.setLabel(label);
        addClickHandler(marker, infoWindow);
        map.addOverlay(marker);
      }
    }
    //向地图添加控件
    function addMapControl() {
      var scaleControl = new BMap.ScaleControl({
        anchor: BMAP_ANCHOR_BOTTOM_LEFT,
      });
      scaleControl.setUnit(BMAP_UNIT_IMPERIAL);
      map.addControl(scaleControl);
      var navControl = new BMap.NavigationControl({
        anchor: BMAP_ANCHOR_TOP_LEFT,
        type: BMAP_NAVIGATION_CONTROL_LARGE,
      });
      map.addControl(navControl);
      var overviewControl = new BMap.OverviewMapControl({
        anchor: BMAP_ANCHOR_BOTTOM_RIGHT,
        isOpen: true,
      });
      map.addControl(overviewControl);
    }
    var map;
    initMap();
    //组件切换顶部
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    //请求公司信息
    this.axios.get("/we").then((res) => {
      this.we = res.data.results;
      this.url = require(`../assets/home/${this.we[0].eurl}`);
    });
    //请求门店信息
    this.axios.get("/shop").then((res) => {
      this.shop = res.data.results;
    });
    window.onload = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
      this.$store.commit("slideshowHeight", this.slideshow_height);
    };
    window.onresize = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
    };
    window.onscroll = function() {
      let scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop;
      let toTop = document.getElementById("nav");
      this.webWidth = document.body.clientWidth;
      if (this.webWidth >= 992) {
        if (scrollTop == 0) {
          toTop.style.backgroundColor = "transparent";
        } else {
          toTop.style.backgroundColor = "#000";
        }
      }
    };
  },
};
</script>
