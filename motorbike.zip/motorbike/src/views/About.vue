<template>
  <div class="about">
    <h1>This is an about page</h1>
    <div v-if="is">11</div>
    <div v-else>22</div>
  </div>
</template>
<script>
export default {
  data(){
    return {
      is:false
    }
  }
}
</script>