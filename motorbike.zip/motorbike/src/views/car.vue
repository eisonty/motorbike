<template>
  <div>
    <!-- 购物车 -->
    <router-link to="/shopping">
      <img class="gouwu" src="../assets/home/gouwu.png" alt="" />
    </router-link>
    <!-- md导航 -->
    <el-row class="phone_nav" v-if="this.$store.state.isMdwidth">
      <el-col class="phone_nav_img">
        <img class="phone_nav_logo" src="../assets/home/logocar.png" />
        <img
          @click="more"
          class="phone_nav_more"
          v-if="this.isMore"
          src="../assets/home/more.png"
        />
        <img
          @click="more"
          class="phone_nav_more_on"
          v-else
          src="../assets/home/more_on.png"
        />
        <div class="phone_nav_more_con" v-if="this.isMore">
          <img class="phone_nav_logo" src="../assets/home/logocar.png" />
          <img
            @click="more"
            class="phone_nav_more"
            v-if="this.isMore"
            src="../assets/home/more.png"
          />
          <img
            @click="more"
            class="phone_nav_more_on"
            v-else
            src="../assets/home/more_on.png"
          />
          <div class="phone_more_nav">
            <!-- 登录状态 -->
            <el-col :xs="24" class="herder_nav" v-if="this.$store.state.login">
              <img @click="nologin" src="../assets/home/islogin.png" alt="" />
            </el-col>
            <el-col v-else class="herder_nav" :xs="24">
              <router-link class="herder_login" to="/login">登录</router-link>
              <div class="herder_login">/</div>
              <router-link class="herder_login" to="/register"
                >注册</router-link
              > </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/">首页</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/product">产品</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/journalism">新闻</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/car">车展</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/we">我们</router-link> </el-col
            ><br />
            <hr />
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- lg导航 -->
    <el-container>
      <el-header id="nav" v-if="this.$store.state.iswidth" class="herder_logo">
        <el-row :gutter="20">
          <el-col :md="5">
            <img class="herder_img" src="../assets/home/logocar.png" />
          </el-col>
          <el-col :md="16" class="herder_nav">
            <el-col :md="2">
              <router-link to="/">首页</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/product">产品</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/journalism">新闻</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/car">车展</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/we">我们</router-link>
            </el-col>
          </el-col>
          <!-- 登录状态 -->
          <el-col :md="3" class="login_img" v-if="this.$store.state.login">
            <img @click="nologin" src="../assets/home/islogin2.png" alt="" />
          </el-col>
          <el-col v-else class="herder_nav" :md="3">
            <router-link class="herder_login" to="/login">登录</router-link>
            <div class="herder_login">/</div>
            <router-link class="herder_login" to="/register">注册</router-link>
          </el-col>
        </el-row>
        <div class="bg a"></div>
      </el-header>
    </el-container>
    <div class="product" :style="this.image"></div>
    <div class="product_content">
      <el-row class="car">
        <el-col
          class="carImage"
          v-for="(v, k) of carimage"
          :key="k"
          :sm="24"
          :md="8"
        >
          <img class="car_img" :src="v" />
        </el-col>
      </el-row>
      <div class="content_det_wire"></div>
      <!-- 底部公司信息 -->
      <el-row class="content_end" v-for="(v, k) of we" :key="k">
        <el-col :xs="24" :md="16">
          <el-col class="content_end_my" :xs="24">联系我们</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.postcode
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12"
            >{{ v.cphone }}1</el-col
          >
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cspecial
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cmail
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24">{{ v.csite }}</el-col>
          <el-col class="content_end_my" :xs="24">
            <img
              class="content_end_my_iconfont"
              src="../assets/home/xinlang.png"
            />
            <img
              class="content_end_my_iconfont"
              src="../assets/home/gongzhonghao.png"
            />
            <img class="content_end_my_iconfont" src="../assets/home/qq.png" />
          </el-col>
        </el-col>
        <el-col class="content_end_my" :xs="24" :md="8">关注我们</el-col>
        <el-col class="content_end_my_code" :xs="24" :md="8">
          <img class="content_end_my_code_font" :src="url" />
          <div style="padding-top:10px">微信公众号</div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      drawer: false,
      image: {
        backgroundImage: "url(" + require("../assets/home/870_w2000.jpg") + ")",
      },
      //pc端导航显示
      iswidth: true,
      //手机屏幕下的导航显示
      isMdwidth: false,
      //导航栏更多状态
      isMore: false,
      //可视界面宽度
      webWidth: document.body.clientWidth,
      //轮播图
      slideshow: "margin-top: -70px;",
      slideshow_height: "",
      isSlideshow: 70,
      //公司信息数据
      we: {},
      //二维码
      url: "",
      //车展图片
      carimage: [],
    };
  },
  methods: {
    nologin() {
      this.$store.commit("isLogin", false);
      sessionStorage.removeItem("login");
      sessionStorage.removeItem("id");
      sessionStorage.removeItem("son");
    },
    more() {
      this.isMore = !this.isMore;
    },
    md() {
      this.iswidth = false;
      this.isMdwidth = true;
      this.slideshow = "margin-top: 47px;";
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
    lg() {
      this.iswidth = true;
      this.isMdwidth = false;
      this.slideshow = `margin-top: ${this.isSlideshow}px;`;
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
  },
  watch: {
    webWidth() {
      if (this.webWidth <= 992) {
        this.md();
      } else {
        this.lg();
      }
    },
  },
  mounted() {
    //组件切换顶部
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    //请求公司信息
    this.axios.get("/we").then((res) => {
      this.we = res.data.results;
      this.url = require(`../assets/home/${this.we[0].eurl}`);
    });
    //请求车展图片url
    this.axios.get("/car").then((res) => {
      let carimage = res.data.results[0].carimage;
      carimage = carimage
        .substr(1, carimage.length - 1)
        .substr(0, carimage.length - 2)
        .split(",");
      for (let item of carimage) {
        this.carimage.push(require(`../assets/home/${item}`));
      }
    });
    window.onload = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
      this.$store.commit("slideshowHeight", this.slideshow_height);
    };
    window.onresize = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
    };
    window.onscroll = function() {
      let scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop;
      let toTop = document.getElementById("nav");
      this.webWidth = document.body.clientWidth;
      if (this.webWidth >= 992) {
        if (scrollTop == 0) {
          toTop.style.backgroundColor = "transparent";
        } else {
          toTop.style.backgroundColor = "#000";
        }
      }
    };
  },
};
</script>
