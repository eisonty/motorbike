<template>
  <div>
    <!-- 购物车 -->
    <router-link to="/shopping">
      <img class="gouwu" src="../assets/home/gouwu.png" alt="" />
    </router-link>
    <!-- md导航 -->
    <el-row class="phone_nav" v-if="this.$store.state.isMdwidth">
      <el-col class="phone_nav_img">
        <img class="phone_nav_logo" src="../assets/home/logocar.png" />
        <img
          @click="more"
          class="phone_nav_more"
          v-if="this.isMore"
          src="../assets/home/more.png"
        />
        <img
          @click="more"
          class="phone_nav_more_on"
          v-else
          src="../assets/home/more_on.png"
        />
        <div class="phone_nav_more_con" v-if="this.isMore">
          <img class="phone_nav_logo" src="../assets/home/logocar.png" />
          <img
            @click="more"
            class="phone_nav_more"
            v-if="this.isMore"
            src="../assets/home/more.png"
          />
          <img
            @click="more"
            class="phone_nav_more_on"
            v-else
            src="../assets/home/more_on.png"
          />
          <div class="phone_more_nav">
            <!-- 登录状态 -->
            <el-col :xs="24" class="herder_nav" v-if="this.$store.state.login">
              <img @click="nologin" src="../assets/home/islogin.png" alt="" />
            </el-col>
            <el-col v-else class="herder_nav" :xs="24">
              <router-link class="herder_login" to="/login">登录</router-link>
              <div class="herder_login">/</div>
              <router-link class="herder_login" to="/register"
                >注册</router-link
              > </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/">首页</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/product">产品</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24">
              <router-link to="/journalism">新闻</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/car">车展</router-link> </el-col
            ><br />
            <hr />
            <el-col :xs="24"> <router-link to="/we">我们</router-link> </el-col
            ><br />
            <hr />
          </div>
        </div>
      </el-col>
    </el-row>
    <!-- 轮播图 -->
    <el-carousel
      :style="this.$store.state.slideshow"
      trigger="click"
      :height="this.$store.state.slideshow_height"
    >
      <el-carousel-item v-for="(item, i) in slideshowUrl" :key="i">
        <img class="dom_bg" :src="item" />
      </el-carousel-item>
    </el-carousel>
    <!-- lg导航 -->
    <el-container>
      <el-header id="nav" v-if="this.$store.state.iswidth" class="herder_logo">
        <el-row>
          <el-col :md="3">
            <img class="herder_img" src="../assets/home/logocar.png" />
          </el-col>
          <el-col :md="18" class="herder_nav">
            <el-col :md="2">
              <router-link to="/">首页</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/product">产品</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/journalism">新闻</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/car">车展</router-link>
            </el-col>
            <el-col :md="2">
              <router-link to="/we">我们</router-link>
            </el-col>
          </el-col>
          <!-- 登录状态 -->
          <el-col :md="3" class="login_img" v-if="this.$store.state.login">
            <img @click="nologin" src="../assets/home/islogin2.png" alt="" />
          </el-col>
          <el-col v-else class="herder_nav" :md="3">
            <router-link class="herder_login" to="/login">登录</router-link>
            <div class="herder_login">/</div>
            <router-link class="herder_login" to="/register">注册</router-link>
          </el-col>
        </el-row>
        <div class="bg a"></div>
      </el-header>
    </el-container>
    <!-- 内容部分 -->
    <div class="content">
      <div class="content_logo">
        <img class="content_logo_img" src="../assets/home/3917_j5nnw4bg.png" />
      </div>
      <div class="content_logo_font">最时尚炫酷的产品，最安全可靠的渠道</div>
      <el-row>
        <!-- 爆款商品 -->
        <div v-for="(v, i) of hotProduct" :key="i">
          <router-link class="router" to="/details">
            <el-col
              :xs="24"
              :md="12"
              :lg="8"
              class="product_content_commodity "
            >
              <div
                @click="son(v.id)"
                :style="`background-image: url(${v.sImage[0]})`"
                class="product_content_commodity_bg"
              >
                <div class="product_content_commodity_font">
                  <div>{{ v.pname }}</div>
                  <div>{{ v.price }}</div>
                </div>
              </div>
            </el-col>
          </router-link>
        </div>
      </el-row>
      <div class="content_my">
        <img class="content_logo_img" src="../assets/home/3917_j85pjaoi.png" />
        <div class="content_logo_font">最时尚炫酷的产品，最安全可靠的渠道</div>
      </div>
      <el-row class="content_my_buttom">
        <!-- 视频播放 -->
        <el-col :xs="24" :md="12">
          <video
            width="583px"
            height="313px"
            autoplay
            controls
            muted
            loop
            :src="videoUrl"
          ></video>
        </el-col>
        <el-col
          v-for="(v, i) of we"
          :key="i"
          class="content_my_wen"
          :xs="24"
          :md="12"
        >
          <p class="content_my_wen_tit">{{ v.cname }}</p>
          <p class="content_my_wen_zi">{{ v.cdetails }}</p>
          <router-link to="/we" class="content_my_wen_a">了解更多</router-link>
        </el-col>
      </el-row>
      <div class="content_my_bg" :style="Img[0]">
        <div class="content_my_over">
          <div class="content_my_over_top">
            速度是心跳的<span style="color:rgb(224,10,10);">开始</span>
          </div>
          <div class="content_my_over_center">
            一个从未尝试冒险过的人，必然是一个失败的人，只要能执着远大的理想，且有不达目的绝不终止的意愿，
          </div>
          <div class="content_my_over_center">便能产生惊人的力量。</div>
          <div class="content_my_over_bottom">
            <router-link to="/car" class="content_my_wen_a"
              >立即体验</router-link
            >
          </div>
        </div>
      </div>
      <div class="content_logo">
        <img src="../assets/home/3917_j85pjxk6.png" class="content_logo_img" />
        <div class="content_logo_font_new">
          最时尚炫酷的产品，最安全可靠的渠道
        </div>
      </div>
      <el-row>
        <!-- 最新商品 -->
        <div v-for="(v, i) of newProduct" :key="i">
          <router-link class="router" to="/details">
            <el-col
              :xs="24"
              :md="12"
              :lg="8"
              class="product_content_commodity "
            >
              <div
                @click="son(v.id)"
                :style="`background-image: url(${v.sImage[0]})`"
                class="product_content_commodity_bg"
              >
                <div class="product_content_commodity_font">
                  <div>{{ v.pname }}</div>
                  <div>{{ v.price }}</div>
                </div>
              </div>
            </el-col>
          </router-link>
        </div>
      </el-row>
      <el-row>
        <el-col :xs="24" :lg="12" class="content_new_ove">
          <div :style="Img[1]" class="content_new_bg">
            <div class="content_new_bg_lucency">
              <div class="content_new_bg_tit">全手工机械机车系列</div>
              <div class="content_new_bg_cen">精致外观+经济性能</div>
              <div>
                <router-link
                  to="/journalism"
                  class="content_my_wen_a content_new_bg_a"
                  >了解更多</router-link
                >
              </div>
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :lg="12" class="content_new_ove">
          <div :style="Img[2]" class="content_new_bg">
            <div class="content_new_bg_lucency">
              <div class="content_new_bg_tit">高端赛车手配置机车系列</div>
              <div class="content_new_bg_cen">精致外观+经济性能</div>
              <div>
                <router-link
                  to="/journalism"
                  class="content_my_wen_a content_new_bg_a"
                  >了解更多</router-link
                >
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
      <div class="content_logo">
        <img src="../assets/home/3917_j85plyg8.png" class="content_logo_img" />
        <div class="content_logo_font">最时尚炫酷的产品，最安全可靠的渠道</div>
      </div>
      <div>
        <div class="content_det" v-for="(v, k) of journalism" :key="k">
          <router-link to="/journalism" class="content_logo__a">
            <div class="content_det_sty">
              <div class="content_det_font_tit">{{ v.title }}</div>
              <div class="content_det_font_cen">{{ v.content }}</div>
            </div>
          </router-link>
        </div>
      </div>
      <div class="content_det_wire"></div>
      <!-- 底部公司信息 -->
      <el-row class="content_end" v-for="(v, i) of we" :key="i">
        <el-col :xs="24" :md="16">
          <el-col class="content_end_my" :xs="24">联系我们</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.postcode
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12"
            >{{ v.cphone }}1</el-col
          >
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cspecial
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24" :md="12">{{
            v.cmail
          }}</el-col>
          <el-col class="content_end_my_con" :xs="24">{{ v.csite }}</el-col>
          <el-col class="content_end_my" :xs="24">
            <img
              class="content_end_my_iconfont"
              src="../assets/home/xinlang.png"
            />
            <img
              class="content_end_my_iconfont"
              src="../assets/home/gongzhonghao.png"
            />
            <img class="content_end_my_iconfont" src="../assets/home/qq.png" />
          </el-col>
        </el-col>
        <el-col class="content_end_my" :xs="24" :md="8">关注我们</el-col>
        <el-col class="content_end_my_code" :xs="24" :md="8">
          <img class="content_end_my_code_font" :src="url" />
          <div style="padding-top:10px">微信公众号</div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      drawer: false,
      //pc端导航显示
      iswidth: true,
      //手机屏幕下的导航显示
      isMdwidth: false,
      //背景装饰图
      Img: [
        {
          backgroundImage:
            "url(" + require("../assets/home/3917_j5sxsdco.jpg") + ")",
        },
        {
          backgroundImage:
            "url(" + require("../assets/home/1265_w2000.jpg") + ")",
        },
        {
          backgroundImage:
            "url(" + require("../assets/home/2722_w2000.jpg") + ")",
        },
      ],
      //导航栏更多状态
      isMore: false,
      //可视界面宽度
      webWidth: document.body.clientWidth,
      //轮播图高度自适应
      slideshow: "",
      slideshow_height: "1166px",
      isSlideshow: 70,
      //公司信息数据
      we: {},
      //二维码
      url: "",
      //商品图片
      Img1: [
        {
          backgroundImage:
            "url(" +
            require("../assets/home/0e577499bb301f9e1f352167969b0e11.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/3db60f8698d3c176cc2f033531e13065.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/399bbed4df3a255037e928b14f4013f8.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/7b01fa6bd846b712cf1ccdbaf779947d.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/ce38f89251255d37d8401ff74144846e.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/2e2c212b094b3d1cb696448af6dd8723.jpg") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/53a8e126d407eed1ef3fe20f5fc72cbe.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/3d8a9637b786fc92dd92a0f41265448c.png") +
            ")",
        },
        {
          backgroundImage:
            "url(" +
            require("../assets/home/35445693ebce4339c15839e5cc3bc8af.png") +
            ")",
        },
      ],
      //新闻数据
      journalism: {},
      //轮播图url
      slideshowUrl: [],
      //视频url
      videoUrl: "",
      //商品列表
      product: {},
      //爆款商品
      hotProduct: [],
      //最新商品
      newProduct: [],
    };
  },
  methods: {
    nologin() {
      this.$store.commit("isLogin", false);
      sessionStorage.removeItem("login");
      sessionStorage.removeItem("id");
      sessionStorage.removeItem("son");
    },
    more() {
      this.isMore = !this.isMore;
    },
    md() {
      this.iswidth = false;
      this.isMdwidth = true;
      this.slideshow = "margin-top: 47px;";
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
    lg() {
      this.iswidth = true;
      this.isMdwidth = false;
      this.slideshow = `margin-top: ${this.$store.state.isSlideshow}px;`;
      this.$store.commit("upWidth", this.iswidth);
      this.$store.commit("upWidth2", this.isMdwidth);
      this.$store.commit("isMar", this.slideshow);
    },
    //传递商品id
    son(val) {
      this.$store.commit("upSon", val);
      sessionStorage.setItem("son", val);
    },
  },
  watch: {
    webWidth() {
      if (this.webWidth <= 992) {
        this.md();
      } else {
        this.lg();
      }
    },
  },
  mounted() {
    //组件切换顶部
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    //请求公司信息
    this.axios.get("/we").then((res) => {
      this.we = res.data.results;
      this.url = require(`../assets/home/${this.we[0].eurl}`);
    });
    //获取新闻内容接口
    this.axios.get("/journalism").then((res) => {
      this.journalism = res.data.results;
    });
    //请求轮播图及视频url
    this.axios.get("/car").then((res) => {
      let slideshow = res.data.results[0].slideshow;
      this.videoUrl = require(`../assets/home/${res.data.results[0].video}`);
      slideshow = slideshow
        .substr(1, slideshow.length - 1)
        .substr(0, slideshow.length - 2)
        .split(",");
      for (let item of slideshow) {
        this.slideshowUrl.push(require(`../assets/home/${item}`));
      }
    });
    //请求商品列表
    this.axios.get("/product").then((res) => {
      this.product = res.data.results;
      for (let value of this.product) {
        let product = value.plimage;
        product = product
          .substr(1, product.length - 1)
          .substr(0, product.length - 2)
          .split(",");
        let sImage = [];
        for (let item of product) {
          sImage.push(require(`../assets/home/${item}`));
        }
        value.sImage = sImage;
      }
      for (let i = 0; i < 3; i++) {
        this.hotProduct.push(this.product[i]);
      }
      for (let i = 3; i < 9; i++) {
        this.newProduct.push(this.product[i]);
      }
    });
    window.onload = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
      this.$store.commit("slideshowHeight", this.slideshow_height);
      this.$store.commit("slideshow", this.isSlideshow);
    };
    window.onresize = () => {
      this.webWidth = document.body.clientWidth;
      this.slideshow_height = this.webWidth / 1.64 - 47 + "px";
      this.isSlideshow = -(this.webWidth / 27.3);
      this.$store.commit("slideshowHeight", this.slideshow_height);
      this.$store.commit("slideshow", this.isSlideshow);
    };
    window.onscroll = function() {
      let scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop;
      let toTop = document.getElementById("nav");
      this.webWidth = document.body.clientWidth;
      if (this.webWidth >= 992) {
        if (scrollTop == 0) {
          toTop.style.backgroundColor = "transparent";
        } else {
          toTop.style.backgroundColor = "#000";
        }
      }
    };
  },
};
</script>
